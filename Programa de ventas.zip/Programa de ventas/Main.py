import tkinter as tk
from UI.gui_app import Frame, barra_menu

def main():
    root = tk.Tk()
    root.title("Programa de ventas")
    root.iconbitmap()
    root.resizable()
    barra_menu(root)

    app = Frame(root = root)

    app.mainloop()


if __name__ == "__main__":
    main()
